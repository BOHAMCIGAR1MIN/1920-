package p404Collection;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest implements Comparable<TreeSetTest>{
	private int id;
	private String name;
	
	public TreeSetTest(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	@Override
	public int compareTo(TreeSetTest o) {
		return id - o.id;
	}
	public static void main(String[] args) {
		Set<Integer> setI = new TreeSet<>();

		setI.add(5);
		setI.add(1);
		setI.add(5);
		System.out.println(setI.size());
		
		Set<TreeSetTest> setT = new TreeSet<>();
		setT.add(new TreeSetTest(2, "a"));
		setT.add(new TreeSetTest(3, "b"));
		setT.add(new TreeSetTest(4, "d"));
		setT.add(new TreeSetTest(5, "c"));
		System.out.println(setT.size());
	}
}
