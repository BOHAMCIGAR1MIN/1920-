package constructor;

public class PersonTest {

	public static void main(String[] args) {
		Person ȫ�浿 = new Person();
		ȫ�浿.setName("ȫ�浿");
		ȫ�浿.setHeight(150);
		System.out.println(ȫ�浿);

		Person lee = new Person("�̼���");
		System.out.println(lee);

		Person me = new Person("���ؼ�", 170, 78);
		System.out.println(me);
	}

}
