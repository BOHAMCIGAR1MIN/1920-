package p395restrictedGeneric;

public interface IIIIIIII {

}
