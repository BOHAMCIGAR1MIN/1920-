package p395restrictedGeneric;

/**
 * ������
 * @author kosmo
 *
 */
public abstract class Party {
	private long id;
	private String name;
}
