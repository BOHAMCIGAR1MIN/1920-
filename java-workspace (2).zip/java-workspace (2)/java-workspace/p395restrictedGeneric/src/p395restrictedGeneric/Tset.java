package p395restrictedGeneric;

import java.util.ArrayList;
import java.util.List;

public class Tset {

	public static void main(String[] args) {
		List<Propessor> jjj = new ArrayList<>();
		jjj.add(new Propessor());
		print(jjj);

		List<Managert> setwser = new ArrayList<>();
		setwser.add(new Managert());
		print(setwser);

		List<Server> sdfasdf = new ArrayList<>();
		sdfasdf.add(new Managert());
		sdfasdf.add(new Propessor());
		print(sdfasdf);
	}

	//Server Ȯ���� ������ ����� ������
	private static <T extends Server> void print(List<T> list) {
		for (T p : list) {
			System.out.println(p);
		}
	}

	private static <T extends IIIIIIII> void printIIII(List<T> list) {
		//���� ����
		for (T p : list) {
			System.out.println(p);
		}
	}
}
