package p395restrictedGeneric;

public abstract class Client extends Party {

}
