package p395restrictedGeneric;

public class Propessor extends Server {

	@Override
	public String toString() {
		return "Propessor []";
	}

}
