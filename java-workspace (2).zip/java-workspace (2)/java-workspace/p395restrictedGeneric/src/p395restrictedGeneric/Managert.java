package p395restrictedGeneric;

public class Managert extends Server {

	@Override
	public String toString() {
		return "Managert []";
	}

}
