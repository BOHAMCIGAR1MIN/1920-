package p395restrictedGeneric;

public class Student extends Client {

}
