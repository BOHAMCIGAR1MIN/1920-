package p395restrictedGeneric;

public class Server extends Party {

}
