package control;

import view.BoardViewer;

public class BoardController {

	public static void main(String[] args) {
		BoardViewer.display();
	}

}
