package thisex;

class Person {
	String name;
	int age;
	
	Person() {
		this("�͸���", 1);
	}
	
	Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	Person getYou() {
		return this;
	}
}

public class CallAnotherConst {

	public static void main(String[] args) {
		Person p = new Person();
		
		System.out.println(p.name);
		System.out.println(p.age);
		
		Person a = p.getYou();
		
		System.out.println(p);
		System.out.println(a);
	}

}
