package view;

import model.Board;
import model.Cell;

public class BoardViewer {

	public static void display() {
		Board board = Board.getInstance();
		//-------------------- ���� ���� �β����� ����
		String coverLine = genCoverLine();
		System.out.print(coverLine);
		
		String emptyLine = genEmptyLine();
		String interLine = genInterLine();

		boolean isFirstLine = true;
		for (Cell[] row : board.getCells()) {
			if (isFirstLine) {
				isFirstLine = false;
			} else {
				System.out.print(interLine);
			}
			
			System.out.print(emptyLine);
			System.out.print('|');
			for (Cell cell : row) {
				System.out.print(' ');
				if (cell.getStone() == null) {
					System.out.print(' ');
				} else {
					System.out.print(cell.getStone().getShape());
				}
				System.out.print(' ');
				System.out.print('|');
			}
			System.out.println();
			System.out.print(emptyLine);
		}
		//-------------------- ���� �Ʒ��� �β����� ����
		System.out.print(coverLine);
	}

	//private : �� Ŭ���� �ȿ����� ���
	//static : static�� �Լ������� static�� �Լ� �� �θ� �� �־��
	private static String genCoverLine() {
		StringBuilder sb = new StringBuilder();
		
		for (int i = 0; i < Board.ROOT * 4 + 1; i++) {
			sb.append('-');
		}
		sb.append('\n');	//new line. �ٹٲ� ����
		return sb.toString();
	}

	/**
	 * | + 3[s s s |]
	 * @return
	 */
	private static String genEmptyLine() {
		StringBuilder sb = new StringBuilder("|");
		
		for (int i = 0; i < Board.ROOT; i++) {
			sb.append("   |");
		}
		sb.append('\n');	//new line. �ٹٲ� ����
		return sb.toString();
	}

	/**
	 * | 2[---+] ---|
	 * @return
	 */
	private static String genInterLine() {
		StringBuilder sb = new StringBuilder("|");
		
		for (int i = 0; i < Board.ROOT; i++) {
			sb.append("---");
			if (i < Board.ROOT - 1) {
				sb.append('+');
			} else {
				sb.append('|');
			}
		}
		sb.append('\n');	//new line. �ٹٲ� ����
		return sb.toString();
	}
}
