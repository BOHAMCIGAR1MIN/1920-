package model;

import java.util.ArrayList;
import java.util.List;

public class Cell {
	//
	private Stone ���ε� = null;

	private List<Line> lines = new ArrayList<>();

	public void addLine(Line line) {
		lines.add(line);
	}
	
	public int getAttachecLineCount() {
		return lines.size();
	}
	
	public Stone getStone() {
		return ���ε�;
	}
	
	public boolean hasSameStone(Cell other) {
		return this.���ε� == other.���ε�;
	}

	public void deposite(Stone stone) {
		���ε� = stone;
	}

	public boolean hasStone() {
		return ���ε� != null;
	}
}
