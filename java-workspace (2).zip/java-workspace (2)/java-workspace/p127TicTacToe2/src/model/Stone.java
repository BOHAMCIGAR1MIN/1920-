package model;

public enum Stone {
	Black('O'), White('X');
	
	private char shape;
	
	private Stone(char shape) {
		this.shape = shape;
	}
	
	public char getShape() {
		return shape;
	}
}
