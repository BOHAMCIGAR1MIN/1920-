package control;

public enum WinLoseStatus {
	User, Computer, Draw;
}
