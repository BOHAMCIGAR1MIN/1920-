package model;

public class Target extends Thing {

	public Target(double xPos, double yPos) {
		super(xPos, yPos);
	}

	@Override
	public char getDisplayChar() {
		return '��';
	}

}
