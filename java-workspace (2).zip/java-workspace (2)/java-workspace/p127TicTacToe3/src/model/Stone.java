package model;

public enum Stone {
	White('X'), Black('O');
	
	private char shape;
	
	private Stone(char shape) {
		this.shape = shape;
	}
	
	public char getShape() {
		return shape;
	}
}
