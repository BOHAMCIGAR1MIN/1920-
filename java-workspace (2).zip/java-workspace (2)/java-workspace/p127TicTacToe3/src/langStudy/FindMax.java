package langStudy;

public class FindMax {

	public static void main(String[] args) {
		int[] jhjhjhhj = {5,3,1,7,8,2};
		int max = Integer.MIN_VALUE;
		
		for (int sss : jhjhjhhj) {
			if (sss > max) {
				max = sss;
			}
		}
		System.out.println(max);
	}

}
