package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import classpart.FunctionTest;

class AddTest {

	@Test
	void test() {
		assertTrue(0 == FunctionTest.add(0, 0));
		assertTrue(7 == FunctionTest.add(3, 4));
		assertFalse(8 == FunctionTest.add(3, 4));
	}

}
