package classex;

import java.util.ArrayList;
import java.util.List;

public class TestDynamicLoading {

	public static void main(String[] args) throws Exception {
		List l;
		Class alClass = Class.forName(args[0]);
		l = (List) alClass.newInstance();
		l.add("xdzfh");
		l.add("xdz2222fh");
		l.add("xdzf3333h");
		System.out.println(l);
		
		List<Object> lll = new ArrayList<>();
		lll.add(765);
		lll.add("sadrfyghsedrt");
		lll.add(new TestDynamicLoading());
	}

}
