package sdfhasdf;

public class SayHello {

	public static void main(String[] args) {
		if (args.length > 0) {
			System.out.println(args[0] + "�� �ȳ��ϼ���");
		}
	}

}
