package test;

import org.junit.jupiter.api.Test;

import cooperation.Bus;
import cooperation.Student;
import cooperation.Subway;

class TakeTrans {

	@Test
	void test() {
		Student james = new Student("james", 5000);
		Student tomas = new Student("tomas", 10000);
		
		Bus bus100 = new Bus("100");
		james.takeBus(bus100);
		System.out.println(james);
		
		Subway subway2 = new Subway("2ȣ��");
		tomas.takeSubway(subway2);
		tomas.takeBus(bus100);
		System.out.println(tomas);

		System.out.println(bus100);
		System.out.println(subway2);
	}

}
