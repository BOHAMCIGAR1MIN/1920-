package ObjectClassOverride;

import java.util.ArrayList;
import java.util.List;

public class CA implements Cloneable {
	private int id;
	private String name;
	private List<CB> listArms = new ArrayList<>();
	private List<Integer> listNums= new ArrayList<>();
	
	public static void main(String[] args) {
		CA c1 = new CA(1, "ȫ�浿");
		c1.addArm(new CB(false)); //������ false
		c1.addArm(new CB(true)); ////������ true
		
		try {
			CA c2 = (CA) c1.clone();
			System.out.println(c1);
			System.out.println(c2);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

	private void addArm(CB cb) {
		listArms.add(cb);
	}

	public CA(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		//shallow copy ����� �⺻�̰�
		CA shallow = (CA) super.clone();
		
		//deep clone�� ������ �Ͽ��� �մϴ�.
		shallow.listArms = new ArrayList<>();
		for (CB arm : listArms) {
			shallow.listArms.add((CB) arm.clone());
		}
		CA deep = shallow;
		return deep;
	}

	@Override
	public String toString() {
		return "CA [id=" + id + ", name=" + name + ", listArms=" + listArms + "]";
	}

	
}
