package genericStudy;

public class GenericAdder {

	public static void main(String[] args) {
		System.out.println(add(4, 5));
		System.out.println(add("sdfg", "asdf"));
	}

	private static <T> T add(T a, T b) {
		return a;
	}
}
