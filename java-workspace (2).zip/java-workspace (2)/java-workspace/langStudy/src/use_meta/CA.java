package use_meta;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

public class CA implements Cloneable {
	private int id;
	private String name;
	private List<CB> listArms = new ArrayList<>();
	private List<Integer> listNums= new ArrayList<>();
	
	public static void main(String[] args) throws Exception {
		CA c1 = new CA(1, "ȫ�浿");
		c1.addArm(new CB(false)); //������ false
		c1.addArm(new CB(true)); ////������ true
		
		try {
			CA c2 = (CA) c1.clone();
			System.out.println(c1);
			System.out.println(c2);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		useMeta(c1);
	}

	protected static void useMeta(CA c1)
			throws InstantiationException, IllegalAccessException, InvocationTargetException {
		Class classOdC1 = c1.getClass();
		
		Constructor[] constructors = classOdC1.getConstructors();
		for (Constructor con : constructors) {
			CA c3 = (CA) con.newInstance();
			System.out.println(c3);
		}
	}

	private void addArm(CB cb) {
		listArms.add(cb);
	}

	public CA() {
		super();
		this.id = 1;
		this.name = "�̼���";
	}

	public CA(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		//shallow copy ����� �⺻�̰�
		CA shallow = (CA) super.clone();
		
		//deep clone�� ������ �Ͽ��� �մϴ�.
		shallow.listArms = new ArrayList<>();
		for (CB arm : listArms) {
			shallow.listArms.add((CB) arm.clone());
		}
		CA deep = shallow;
		return deep;
	}

	@Override
	public String toString() {
		return "CA [id=" + id + ", name=" + name + ", listArms=" + listArms + "]";
	}

	
}
