package use_meta;

public class CB implements Cloneable {
	private boolean side;

	public CB(boolean side) {
		super();
		this.side = side;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
