package objectName;

import java.util.Objects;

public class C1 implements Cloneable {
	private int a;
	private String b;
	private double c;
	
	public static void main(String[] args) throws CloneNotSupportedException {
		C1 c = new C1(1, "ȫ�浿", 0.8);
		System.out.println(c.getClass().getName());
		
		String x = "345678rdtfyguhjgyktlvchlkhbnlijyvbyyydjvy,";
		String y = "345678rdtfyguhjgyktlvchlk8bnlijyvbyyydjvy,";
		
		System.out.println(x.hashCode());
		System.out.println(y.hashCode());
		C1 d = (C1) c.clone();
		
		System.out.println(c);
		System.out.println(d);
	}

	public C1(int a, String b, double c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}

	@Override
	public int hashCode() {
		return Objects.hash(a, b, c);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		C1 other = (C1) obj;
		return a == other.a && Objects.equals(b, other.b)
				&& Double.doubleToLongBits(c) == Double.doubleToLongBits(other.c);
	}

	@Override
	public String toString() {
		return "C1 [a=" + a + ", b=" + b + ", c=" + c + "]";
	}
	
}
