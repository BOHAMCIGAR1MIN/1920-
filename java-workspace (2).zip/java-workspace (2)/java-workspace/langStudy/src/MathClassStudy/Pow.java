package MathClassStudy;

public class Pow {

	public static void main(String[] args) {
		int a = 10;
		for (int b = 0; b < 3; b++) {
			System.out.println(a + " ^ " + b + " = " + (int) Math.pow(a, b));
			
		}
	}

}
