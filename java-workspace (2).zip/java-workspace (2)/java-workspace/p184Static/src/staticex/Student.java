package staticex;

public class Student {
	public static int serialNum = 1000;
	public int id;
	public String name;
	
	public Student() {
		serialNum++;
		id = serialNum;
	}
}
