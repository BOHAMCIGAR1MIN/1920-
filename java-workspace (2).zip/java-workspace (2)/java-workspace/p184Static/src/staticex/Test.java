package staticex;

public class Test {

	public static void main(String[] args) {
		Student �� = new Student();
		System.out.println(��.serialNum);
		Student �� = new Student();
		System.out.println(��.serialNum);
		Student �� = new Student();
		System.out.println(��.serialNum);
	}

}
