package model;
/**
 * ����
 * @author kosmo
 *
 */

public class Course {
	private String name; //�̸�

	public Course(String name) {
		super();
		this.name = name;
	}
	
	
}
