package singleton;

public class Test {

	public static void main(String[] args) {
		//chain
		System.out.println(Company.getInstance().getName());
	}

}
