package p80_shiftOperator;

public class ShiftLeft {

	public static void main(String[] args) {
		int val = 3;
		//0B00000000000000000000110000000000
		val <<= 10;
		val *= 1024;
		//0B00000000000000000000000000001100
		System.out.println(val);
		
		
		val = -3;
		//0B11111111111111111111111111111101 
		val <<= 3;
		//0B11111111111111111111111111110100
		System.out.println(val);
		
		val = -8;
		//0B11111111111111111111111111111000 
		val >>>= 3;
		//0B00011111111111111111111111111111 
		System.out.println(val);

		int val1 = 0B00000000001000000000100000010001;
		final int MALE_MASK = 0B00000000000000000000000000011111;
		int male = val1 & MALE_MASK;
		System.out.println(male);//17
		
		
		int aaa = 5 < 3 ? 33 : 7 == (6 > 3 ? 7 : 8) ? 22 : 44;
	}

}
