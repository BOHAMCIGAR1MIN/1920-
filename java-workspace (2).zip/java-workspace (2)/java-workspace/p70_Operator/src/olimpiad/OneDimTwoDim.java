package olimpiad;

public class OneDimTwoDim {

	public static void main(String[] args) {
		int[] problem = {3, 5, 6, 6, 5, 7};	//�迭
		int[][] answer;

	}

}
