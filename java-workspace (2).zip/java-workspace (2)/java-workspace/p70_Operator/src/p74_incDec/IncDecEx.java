package p74_incDec;

public class IncDecEx {

	public static void main(String[] args) {
		int score = 150;
		int lastScore = ++score;
		
		System.out.println(lastScore); 	//151
		System.out.println(score); 	//151
	}

}
