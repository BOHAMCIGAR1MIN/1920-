package interfaceex;

public interface Calc {
	double PI = 3.14;
	
	int add(int num1, int num2);
}
