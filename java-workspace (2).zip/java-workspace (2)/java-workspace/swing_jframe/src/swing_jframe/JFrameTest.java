package swing_jframe;

import javax.swing.JFrame;

public class JFrameTest {

	public static void main(String[] args) {
		JFrame win = new JFrame("�����α׷�");
		win.setSize(300, 200);
		win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		win.setVisible(true);
	}

}
