package swing_jframe;

import java.awt.Toolkit;

import javax.swing.JFrame;


public class MyWin extends JFrame {
	public MyWin() {
		Toolkit toolkit = Toolkit.getDefaultTooLkit();
		toolkit.screeSize();
		
		Dimension screenSize= toolkit.size.getscreenSize();
		
		this.setSize(300, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("���ø��µ���");
		toolkit.getImage("");
		this.setVisible(true);
		for(int i = 0; i<5; i++) {
			JButton btn = new JButton("��ư")
		}
		 this.setVisible(ture);
	}
	
	public static void main(String[] args) {
		MyWin myWin = new MyWin();
	}
}
