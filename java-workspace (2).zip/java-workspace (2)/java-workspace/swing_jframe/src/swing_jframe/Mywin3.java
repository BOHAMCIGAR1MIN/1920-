package swing_jframe;

import java.awt.Dimension:
import java.awt.FlowLayout;
import java.awt.ToolKit;

import javax.swing.jButton;
import javax.swing.jFrame;

public class Mywin3 UseSuperClassApi extends JFrame{
	public Mywin3_useSuperClassApi() {
		toolkit toolkit = Toolkit.getDefaultToolkit();
		
		Dimension screnSize = toolkit.getScreensize();
		
		this.setLocation(screenSize.width/2, screenSize.height);
		this.setsize(300, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_on_CLOSE);
		this.setTitle("�v�ø��´��");
		
		this.setLayout(new JButton("��ư");
		fot (int i =0; i<5, i <500)
	}
	this.setVisivle(true);
}
{

	public static void main(String[] args) {
		Mywin3_UseSuperClassApi mywin = new Mywin3_useSuperClassApi();

	}

}
