package swing_jframe;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class MyWin2 extends JFrame {
	public MyWin2() {
		this.setSize(300, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("���ø��µ���");
		
		this.setLayout(new FlowLayout());
		for (int i = 0; i < 5; i++) {
			JButton btn = new JButton("��ư");
			this.add(btn);
		}
		this.setVisible(true);
	}
	
	public static void main(String[] args) {
		MyWin2 myWin = new MyWin2();
	}
}
