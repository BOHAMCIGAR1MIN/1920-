package p232inheritance;

import java.util.HashMap;

public class MyString extends HashMap {

}
