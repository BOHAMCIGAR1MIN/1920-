package p232inheritance;

public class DownClass extends SuperClass {

}
