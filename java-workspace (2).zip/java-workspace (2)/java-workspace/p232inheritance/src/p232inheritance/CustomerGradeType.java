package p232inheritance;

public enum CustomerGradeType {
	Diamond, Gold, Sil, Bron;
}
