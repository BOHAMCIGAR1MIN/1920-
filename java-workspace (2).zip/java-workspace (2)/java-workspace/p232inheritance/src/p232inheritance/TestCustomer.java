package p232inheritance;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCustomer {

	@Test
	void test() {
		Customer lee = new Customer(10010, "�̼���");
		lee.calcBillingAmount(10000);
		System.out.println(lee);
		
		Customer kim = new VipCustomer(100520, "������");
		kim.calcBillingAmount(1000000);
		System.out.println(kim);
	}

}
