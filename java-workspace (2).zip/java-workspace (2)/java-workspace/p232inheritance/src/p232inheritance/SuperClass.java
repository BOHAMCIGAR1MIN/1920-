package p232inheritance;

public class SuperClass {

}
