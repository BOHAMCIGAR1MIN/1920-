package template;

public class AICar extends Car implements ICar, JCar {

	@Override
	protected void drive() {
	}

	@Override
	protected void stop() {
	}

}
