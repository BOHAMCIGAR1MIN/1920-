package template;

public class ManualCar extends Car {

	@Override
	protected void stop() {

	}

	@Override
	protected void drive() {

	}

}
