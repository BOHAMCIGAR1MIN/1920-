package template;

public abstract class Car {
	final public void run() {
		startCar();
		drive();
		stop();
		turnOff();
	}

	private void turnOff() {
	}

	protected abstract void stop();

	protected abstract void drive();

	private void startCar() {
	}
}
