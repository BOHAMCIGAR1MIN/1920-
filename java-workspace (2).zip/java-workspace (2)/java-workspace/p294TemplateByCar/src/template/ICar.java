package template;

public interface ICar {
	//interface inter face => ����
}
