package template;

public interface JCar {

}
