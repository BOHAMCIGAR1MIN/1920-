package CFSingleton;


public class CarFactory {
	private static CarFactory theInstance = new CarFactory();
	
	private CarFactory() {
	}

	public static CarFactory getInstance() {
		return theInstance;
	}

	public Car createCar() {
		return new Car();
	}
}
