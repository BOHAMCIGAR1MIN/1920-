package CFSingleton;

public class Car {
	private static int NUM_SEED = 10000;
	
	private int carNum;
	
	public Car() {
		carNum = ++NUM_SEED;
	}
	
	public int getCarNum() {
		return carNum;
	}
}
