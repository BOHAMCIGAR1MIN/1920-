package test;

import CFSingleton.Car;
import CFSingleton.CarFactory;

public class CarFactoryTest {

	public static void main(String[] args) {
		CarFactory factory = CarFactory.getInstance();
		Car s1 = factory.createCar();
		Car s2 = factory.createCar();
		System.out.println(s1.getCarNum());
		System.out.println(s2.getCarNum());
	}

}
